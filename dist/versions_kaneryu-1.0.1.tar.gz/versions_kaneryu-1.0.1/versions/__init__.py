import versions
from versions.versions import Version

__title__ = 'versions'
__all__ = ['Version']